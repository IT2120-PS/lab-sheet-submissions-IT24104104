setwd("C:\\Users\\User\\Desktop\\IT24104104 Lab Sheet 06")
#Part 2
#It asks to find P (x = 40) .Following command gives the density.
#In other words, probability of getting an exact value can be calculated using "dbinom" command.
dbinom (40,44,0.92)

#Part 3
#It asks to find P(X <= 35) . Following command gives the cumulative #probability (<=), if ""lower.tail" argument equals to "TRUE".
pbinom (35, 44, 0.92, lower.tail = TRUE)

#Part 4
#It asks to find P(X >= 38) . This can find using "pbinom" command as follows.
#You need to rearrange the probability statement as follows.
#P (X >= 38) = 1 - P(X < 38) = 1 - P(X <= 37)
#Then command will be as follows.
1-pbinom (37, 44, 0.92,lower.tail = TRUE)
Or else following command can also used by keeping argument "lower.tail" as "FALSE".
# #Here, when that argument is "FALSE", it means that P(x > 37) which is same as P(X >= 38) .
pbinom (37, 44, 0.92, lower.tail = FALSE)

#Part 5
#It asks to find P(40 <= X <= 42) . This can find using "pbinom" command as follows.
#You need to rearrange the probability statement as follows.
#P (40 <= X <= 42) = P(X <= 42) - P(X <= 39)
#Then command will be as follows.
pbinom (42, 44, 0.92, lower.tail = TRUE)-pbinom (39, 44, 0.92,lower.tail = TRUE)

##Question 02
#Part 1
#Number of babies born in a hospital on a given day

#Part 2
#Poisson distribution
#Here, random variable X has poisson distribution with lambda=5

#Part 3
#It asks to find P(X = 6) . Following command gives the density.
#In other words, probability of getting an exact value can be calculated using "dpois" command.
dpois (6,5)

#Part 4
#It asks to find P(X > 6) . This can find using "ppois" command as follows.
#If you keep "lower.tail" argument as "TRUE", that means P(X <= 6) .
#Since we need P(X > 6) , keep the "lower.tail" argument as "FALSE".
ppois (6, 5, lower.tail = FALSE)



#Exercise
#part1
#1).The distribution of X is Binomial with parameters n=50 and p=0.85 (X ~ Binomial(50, 0.85)).

#2).The probability that at least 47 students passed the test is 0.0460.

#part2.
#1). The random variable (X) for the problem is the number of customer calls received in an hour.
#2). The distribution of X is Poisson with λ=12 (X ~ Poisson(12)).
#3). The probability that exactly 15 calls are received in an hour is 0.0724.
#To arrive at the solution: This is P(X = 15), where X ~ Poisson(λ=12). 
#Using the probability mass function for the Poisson distribution, compute poisson.pmf(15, 12) (or equivalently in R: dpois(15, 12)).













