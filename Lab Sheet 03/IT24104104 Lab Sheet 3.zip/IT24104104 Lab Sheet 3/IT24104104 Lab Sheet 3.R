getwd()
setwd("C:\\Users\\User\\Desktop\\Lab Sheet 3")

##Part 01
#Importing Data set
data<-read.csv("DATA 3.csv", header=TRUE)
#View the file in a separate window
fix(data)
#Renaming column headings
names (data)<-c("Age", "Gender", "Accommodation")
#Converting Gender & Accommodation into factors/categorical variables
data$Gender <- factor(data$Gender, c(1, 2), c("Male", "Female"))
data$Accommodation <- factor(data$Accommodation, c(1, 2, 3), c("Home", "Boarded", "Lodging"))
# Attach the file
attach(data)


##Part 02
gender.freq <-table (Gender)
gender.freq
acc.freq <-table (Accommodation)
acc.freq
barplot (gender.freq, main= "Bar Chart for Gender", ylab= "Frequency", xlab="Gender")
abline (h = 0)
barplot(acc.freq, main= "Bar Chart for Accommodation", ylab ="Frequency", xlab="Accommodation")
abline (h = 0)
pie (gender.freq, main= "Pie Chart for Gender")
pie (acc.freq, main ="Pie Chart for Accommodation")
hist (Age, main="Histogram for Age")
boxplot (Age, main="Box Plot for Age", horizontal=TRUE, outline=TRUE)





##Part 03
gender_acc.freq <- table (Gender, Accommodation)
gender_acc.freq

barplot (gender_acc.freq, beside=FALSE, main = "Gender & Accommodation", legend = rownames (gender_acc.freq),
         xlab="Accommodation", ylab="Frequency")
abline (h = 0)

barplot (gender_acc.freq, beside = TRUE, main = "Gender & Accommodation", legend= rownames (gender_acc.freq),
         xlab="Accommodation", ylab="Frequency")
abline (h = 0)


#Part 04
#Side-by-Side boxplots
boxplot (Age~Gender, main = "Boxplots for Age by Gender", xlab = "Gender", ylab = "Age")
boxplot (Age~Accommodation, outpch = 8, main = "Boxplots for Age by Accommodation", xlab = "Accommodation",ylab = "Age", outline=TRUE)


# Part 05
xtabs (Age~Gender+Accommodation)/gender_acc.freq
detach (data)



##Exercise
#1
student_data<-read.csv("Exercise.csv",header=TRUE)
fix(student_data)

#2
summary(student_data$X1)
hist(student_data$X1, main="Histogram for Age", xlab="Age")

#3
gender_freq <- table(student_data$X2)
barplot(gender_freq, main="Bar Chart for Gender", ylab="Frequency", xlab="Gender", names.arg=c("Male", "Female"))
gender_freq


#4

boxplot(X1 ~ X3, data=student_data, main="Boxplots for Age by Accommodation", xlab="Accommodation", ylab="Age", names=c("Home", "Boarded", "Lodging"))


xtabs(Age ~ Gender + Accommodation, data=student_data)
mean_age <- tapply(student_data$X1, list(student_data$X2, student_data$X3), mean)
detach(data)

